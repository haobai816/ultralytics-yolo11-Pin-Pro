python setup.py install

# python setup.py clean --all